import React from 'react'
import Bg from './bg.jpg'
function HeroSection() {
  return (
    <div align="center">
        <img   src={Bg} ></img>
    </div>
  )
}

export default HeroSection