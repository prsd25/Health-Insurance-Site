import React from 'react'

function NoPage() {
  return (
    <div>NoPage</div>
  )
}

export default NoPage